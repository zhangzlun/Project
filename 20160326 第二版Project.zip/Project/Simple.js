$(document).ready(function () {
	dataLoad();
	showData();
	
});
	        
var dataObj = new Object();
var dataLoad = function() {
		        
	dataObj['book_list'] = {
	  "list" : [ {"isbn":"1", "activity":"選擇活動", "name":"張治倫", "price": 580},
				 {"isbn":"2", "activity":"免費愛滋篩檢", "name":"碁峯資訊股份有限公司", "price": 580},
	  			 {"isbn":"3", "activity":"疫苗施打", "name":"碁峯資訊股份有限公司", "price": 450},
	  			 {"isbn":"4", "activity":"流感疫苗施打", "name":"金禾資訊股份有限公司", "price": 650},
	  			 {"isbn":"5", "activity":"任一活動", "name":"旗標出版股份有限公司", "price": 490},
	  			 {"isbn":"6", "activity":"任二活動", "name":"文魁資訊股份有限公司", "price": 390},
	  			 {"isbn":"7", "activity":"隨便一種活動", "name":"日本實業出版社", "price": 1500} ]
	};
	dataObj['announcement'] = {
	  "list" : [ {"isbn":"1", "activity":"1.可由最新消息及服務項目得知想知道的資訊。"},
				 {"isbn":"2", "activity":"2.門診資訊:可以查詢新北市林口區衛生所的門診資訊。</br>服務項目:目前提供免費的免費心理師諮商 歡迎各位蒞臨。</br>資源連接:各個行政資源的地址和聯絡電話的提供。"},
	  			 {"isbn":"3", "activity":"3.APP可以報名活動，按下登入後依序填完基本資料後再按送出即可。</br>(資料用於登入及管理方統 不會對外公開操作流程)"},
	  			 // {"isbn":"4", "activity":"4.當使用完登入之後，返回至頁面，按下前往問卷，點選完問題之後方可結束。"},
	  			 {"isbn":"5", "activity":"4.最後如果您喜歡我們的APP希望您可以幫我們做個問卷調查，有任何問題或BUG也可以在上面回復。(點我前往問卷)"}]
	};

}
	       
var showData = function() {
    var dataArray = new Array();
    $.each(dataObj['book_list'].list, function(key, value) {
    	dataArray.push('<li>' + '<a  href="#!" class="dataname">'+value.isbn+'</a>' + '</li>');
    });
    	$('ul#dropdown2').html(dataArray.join(""));
 
    var activityArray = new Array();
    $.each(dataObj['book_list'].list, function(key, value) {
    	activityArray.push('<option > '+value.activity+'</option>');
    	
    });
    	$('#activityArray').html(activityArray.join(""));
    	


    var announcementArray = new Array();
    $.each(dataObj['announcement'].list, function(key, value) {
    	announcementArray.push('<a href="#!" class="collection-item">'+value.activity+'</a>');

    });
    	$('#announcement').html(announcementArray.join(""));

}

	        
	       
			
