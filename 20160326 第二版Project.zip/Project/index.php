<!DOCTYPE html>
<html lang="zh-TW">
<head>
	<meta charset="UTF-8">
	<title>APP操作流程說明</title>
	<script src="../js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="../js/materialize.js"></script>
	<script type="text/javascript" src="Simple.js"></script>
	<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="../css/materialize.css"  media="screen,projection"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="../css/animate.css">
	<link rel="stylesheet" href="project.css">
</head>
<script >
	$(document).ready(function(){
		$(".button-collapse").sideNav();
		$('.modal-trigger').leanModal();
		$('.dropdown-button').dropdown({	
		      inDuration: 300,
		      outDuration: 225,
		      constrain_width: true, // Does not change width of dropdown to that of the activator
		      hover: true, // Activate on hover
		      gutter: 0, // Spacing from edge
		      belowOrigin: false, // Displays dropdown below the button
		      alignment: 'right' // Displays dropdown with edge aligned to the left of button
		    });
		$('.datepicker').pickadate({
		    selectMonths: true, // Creates a dropdown to control month
		    selectYears: 15 // Creates a dropdown of 15 years to control year
		  });
		$('select').material_select();	

	});

</script>
<style type="text/css">

</style>
<body>

<?php 
	include 'modals.php';
?>
	<header>
		<div class="row">
			<nav>
			    <div class="nav-wrapper">
					
			      <a href="#" class="brand-logo">APP操作流程說明</a>

			      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
			      <ul id="nav-mobile" class="right hide-on-med-and-down">
			        <li><a class="modal-trigger iconbtu" href="#download"><i class="material-icons">file_download</i></a>
			        </li>
			        <li><a class="modal-trigger" href="#modal7">活動報名</a></li>
			        <li><a class="modal-trigger" href="#modal8">關於我們</a></li>
			      </ul>
			      <ul class="side-nav" id="mobile-demo">
			        <li><a href="sass.html">Sass</a></li>
			        <li><a href="badges.html">Components</a></li>
			        <li><a class="modal-trigger" href="#modal7">Javascript</a></li>
			        <li><a class="modal-trigger" href="#modal8">關於我們</a></li>
			      </ul>
			  	 </div>
			</nav>
			
			<!-- 背景圖 -->
			<div class="imves">
				<div class="bigimg">
					<img src="img/nature_hd_best_of_nature_05_4724_10.jpg">
				</div>
			</div>
		</div>
	</header>
	<main>
		<div class="row">
			<!-- APP使用流程 -->
			<div class="stepall col s12 m6 l4">
				<div class="titleh1">
					<h2>APP使用流程</h2>
				</div> 
				<!-- APP 公告 -->
				<div id="announcement" class="collection">
					<a class="tooltipped collection-item" data-position="right" data-delay="50" data-tooltip="我會跳出文字"></a>
				 </div>
			</div>
			<div class="stepall col s12 m6 l4">
			<ul id="dropdown2" class="dropdown-content">
			    <li><a href="#!" class="dataname">one</a></li>
			    <li><a href="#!" class="dataname">two</a></li>
			    <li><a href="#!" class="dataname">three</a></li>
			  </ul>

			   <a class="btn dropdown-button" href="#!" data-activates="dropdown2">Dropdown<i class="mdi-navigation-arrow-drop-down right"></i></a>
			</div>
		</div>
	</main>

</body>
</html>
